var indexSectionsWithContent =
{
  0: "abcdghjkmnrsw",
  1: "bchkns",
  2: "d",
  3: "adhrs",
  4: "bcgjkmsw",
  5: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "typedefs",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Typedefs",
  5: "Pages"
};

