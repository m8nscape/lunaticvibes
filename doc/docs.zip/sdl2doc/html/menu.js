document.write('<div id=menubar >\
<a href="http://www.libsdl.org/">\
<img alt="SDL Logo" src="SDL_logo20_sm2.png" style="width: 100px; height: 60px;"></img>\
</a>\
<p>\
<a href="FrontPage.html">FrontPage</a><br>\
<a href="Introduction.html">Introduction</a><br>\
<a href="Support.html">Support</a><br>\
<a href="MigrationGuide.html">Migration Guide</a><br>\
<a href="CategoryAPI.html">API by Name</a><br>\
<a href="APIByCategory.html">API By Category</a><br>\
<a href="Changes.html">Changes</a><br>\
</div>');

